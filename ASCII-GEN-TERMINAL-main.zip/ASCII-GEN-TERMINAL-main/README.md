  # ASCII-GEN-TERMINAL
  #### Video Demo:  [https://youtu.be/hENX8NAMBGQ]
  #### Description:
  
    THE REASON WHY I CREATE THIS PROGRAM
       Sure everyone need to improve u programing skill ,And i like ascii art this unique and then i decide to build this program
       and i'm started to research. And i found some library to help me make this project that is pyfiglet and i try it a lot but it doesn't work 
       after that i go to stackoverflow and find why it doesn't work and i fix the problem . NOW i so proud of myself and i write the story in my github
       to the way of my life.
    
    Let start with check the file. We need 3 file. 
    1.project.py
    2.requirements.txt
    3.test_project.py
    
    And then open requirements.txt and install all pip in you terminal.
    pip install pyfiglet 
    pip install termcolor
    pip install colorama
    pip install pytest
    
  #### FUNCTION MAIN FILE:
    We have 3 FUNCION 
    1.ASCII GENERATOR
    2.SELF INTRODUCTION
    3.EXIT
    
    
    FIRST
    Ok i ll explain First FUNCTION. 
        We need to input the word and then the color i contain 8 colors 
                  1.red
                  2.grey
                  3.green
                  4.yellow
                  5.blue
                  6.margenta
                  7.cyan
                  8.white
      And 9 styles
                      1.acrobatic
                     2.alligator
                     3.alphabet
                     4.bell
                     5.broadway
                     6.bubble
                     7.doom
                     8.isometric1
                     9.starwars
                     
                     
     SECOND 
         The second function is contain my self introductionn
     
     THIRD
          if u type anything other 1,2 the Program ll exit
        
  #### TEST FILE :
        i make 3 test
        First one is Color test
        Second one is style test
        And the last one is  Option test
  
  #### NOW you can use all of my promgram
    [x] Add delight to the experience when all tasks are complete :tada:
    HOPE U LIKE MY PROGRAM
  


